const jwt = require('jsonwebtoken');

const authenticateUser = (req, res, next) => {
    const token = req.header('x-auth-token'); // Assuming you send the token in the header
    if (!token) return res.status(401).json({ message: 'Access denied. No token provided.' });

    try {
        const decoded = jwt.verify(token, 'your-secret-key'); // Replace with your secret key
        req.user = decoded;
        next();
    } catch (ex) {
        res.status(400).json({ message: 'Invalid token.' });
    }
};



const requireRole = (role) => {
    return (req, res, next) => {
        const user = req.user; // Assuming you attach the user object to the request
        if (user && user.role === role) {
            next(); // User has the required role, proceed to the route handler
        } else {
            res.status(403).json({ message: 'Access denied.' }); // User does not have the required role
        }
    };
};

module.exports = { requireRole,authenticateUser};
