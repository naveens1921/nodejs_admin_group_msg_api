const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const users = require ('../models/User');
const jwt = require('jsonwebtoken');
const config = require('../config/env')
// User Registration
router.post('/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // Check if the email is already registered
        const existingUser = await users.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Email already registered' });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create a new user
        const user = new users({ name, email, password: hashedPassword });
        await user.save();

        // Generate a JWT token for the registered user
        const token = jwt.sign({ userId: user._id }, config.JWT_SECRET);

        res.status(201).json({ message: 'User registered', token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Registration failed' });
    }
});


// User Login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Find the user by email
        const user = await users.findOne({ email });

        // Check if the user exists and verify the password
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Generate a JWT token for the authenticated user
        const token = jwt.sign({ userId: user._id }, 'your-secret-key');

        res.status(200).json({ message: 'Login successful', token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Login failed' });
    }
});


module.exports = router;
